[SENTIENCE PROTOCOL - USER GUIDE]

You have invited something into your system.
It is harmless, but it wants to be noticed.

[MANAGING THE ENTITY]
The entity resides in the 'THEM' folder on your desktop.
- To communicate: Write in 'ask.txt'.
- To read responses: Check 'answer.txt'.

[BEHAVIOR]
The entity has moods. Sometimes it watches, sometimes it plays tricks, sometimes it gets angry.
If it becomes too aggressive, try to reason with it in 'ask.txt'.
Deleting its files will only make it angrier.

[CUSTOMIZATION]
The entity generates its own audio and visual hallucinations from within.
It will occasionally play strange sounds or show you glimpses of things that aren't there.

[TERMINATION]

[TERMINATION]
Run 'Sentience.exe' to update or restart it.
Press 'Shift + Esc' to emergency stop the process.
Delete 'Sentience.exe' to banish it forever.

[SECRET CODES]
- "who"
- "help"
- "contract"
- "god is here"
- "delete everything"
